## Migration Notice

The contents of this repository have been migrated to a new location. You can find the updated repository here:

[New Repository URL](https://github.com/midas-apps/contracts)
