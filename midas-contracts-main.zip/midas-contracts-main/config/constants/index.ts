export const WEI = 1;
export const GWEI = WEI * 10 ** 9;
export const ETHER = GWEI * 10 ** 9;

export const MOCK_AGGREGATOR_NETWORK_TAG = 'with-mock-aggregator';
